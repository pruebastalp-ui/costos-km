import os

MYSQL_CONFIG = {
    "host": os.environ.get("COSTOS_DB_HOST", "127.0.0.1"),
    "port": int(os.environ.get("COSTOS_DB_PORT", "3306")),
    "user": os.environ.get("COSTOS_DB_USER", "root"),
    "password": os.environ.get("COSTOS_DB_PASSWORD", ""),
    "database": os.environ.get("COSTOS_DB_NAME", "costos_mvp"),
    "autocommit": False,
}
SECRET_KEY = os.environ.get("COSTOS_SECRET_KEY", "cambiar-esto-en-produccion")
