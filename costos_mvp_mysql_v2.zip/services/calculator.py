GROUPS = ["DF", "SGI", "SGI_KM", "SGII", "INP", "UPA", "UPA_KM", "UMA_1", "UMA_2"]


STAFF_CODES = [
    "conductores_x_veh",
    "jefes_trafico_x_veh",
    "inspectores_x_veh",
    "otros_trafico_x_veh",
    "jefes_taller_x_veh",
    "oficiales_mecanicos_x_veh",
    "gomeros_x_veh",
    "otros_mantenimiento_x_veh",
    "gerentes_x_veh",
    "jefes_admin_x_veh",
    "administrativos_x_veh",
    "recaudadores_x_veh",
    "otros_admin_x_veh",
]


def _safe_div(a, b):
    return a / b if b not in (0, None) else 0.0


def _pct(v):
    v = float(v)
    return v / 100.0 if v > 1 else v


def _get(data, code, group, default=0.0):
    try:
        return float(data.get(code, {}).get(group, default))
    except Exception:
        return float(default)


def _copy_results(baseline_results):
    return {code: {g: float(v) for g, v in values.items()} for code, values in baseline_results.items()}


def calculate_results(base_params, scenario_params, baseline_results):
    params = {}
    all_codes = set(base_params) | set(scenario_params)
    for code in all_codes:
        params[code] = {}
        for g in GROUPS:
            params[code][g] = _get(scenario_params, code, g, _get(base_params, code, g, 0.0))

    results = _copy_results(baseline_results)

    base_salary_annual_per_staff = {}
    base_lnh_annual_per_conductor = {}
    seguros_personal_ratio = {}
    km_prod_base = {}
    km_empresa_base = {}
    staff_base = {}
    conductores_base = {}

    for g in GROUPS:
        km_prod_base[g] = _get(base_params, "km_productivo_anual_veh", g, 0.0)
        km_empresa_base[g] = _get(base_params, "km_anual_empresa", g, 0.0)
        staff_base[g] = sum(_get(base_params, code, g, 0.0) for code in STAFF_CODES)
        conductores_base[g] = _get(base_params, "conductores_x_veh", g, 0.0)

        base_salary_annual_per_staff[g] = _safe_div(
            float(baseline_results["salarios_personal"][g]) * km_prod_base[g],
            staff_base[g],
        )
        base_lnh_annual_per_conductor[g] = _safe_div(
            float(baseline_results["lnh"][g]) * km_empresa_base[g],
            conductores_base[g],
        )
        seguros_personal_ratio[g] = _safe_div(
            float(baseline_results["seguros_personal"][g]),
            float(baseline_results["salarios_personal"][g]),
        )

    for g in GROUPS:
        km_prod = _get(params, "km_productivo_anual_veh", g, 0.0)
        km_empresa = _get(params, "km_anual_empresa", g, 0.0)
        parque = _get(params, "parque_movil", g, 0.0)
        km_improd = _pct(_get(params, "km_improductivo_pct", g, 0.0))
        vida_veh_km = _get(params, "vida_util_vehiculo_km", g, 0.0)
        vida_veh_anios = _get(params, "vida_util_vehiculo_anios", g, 0.0)

        # 1. Combustible
        results["combustible"][g] = (
            _get(params, "consumo_combustible", g) * _get(params, "precio_gasoil_sin_iva", g)
        )

        # 2. Lubricantes (siguiendo la hoja Excel)
        results["lubricantes"][g] = (
            (
                _get(params, "consumo_aceite", g) * _get(params, "precio_aceite", g)
                + (_get(params, "consumo_grasa", g) + _get(params, "consumo_aceite_caja", g)) * _get(params, "precio_grasa", g)
            )
            * (1 + km_improd)
        )

        # 3. Neumáticos
        vida_total_juego = _get(params, "vida_util_total_juego", g)
        if not vida_total_juego:
            vida_total_juego = _get(params, "vida_util_neumaticos", g) + (
                _get(params, "recapados_admisibles", g) * _get(params, "prolongacion_recapado", g)
            )
        results["neumaticos"][g] = _safe_div(
            (
                _get(params, "cantidad_cubiertas", g) * _get(params, "precio_cubierta", g)
                + _get(params, "recapados_admisibles", g) * _get(params, "precio_recapado", g) * _get(params, "cantidad_cubiertas", g)
            )
            * (1 + km_improd),
            vida_total_juego,
        )

        # 4. Engrase y lavado
        results["engrase_lavado"][g] = _safe_div(
            _get(params, "engrases_cada_10000", g) * _get(params, "precio_engrase_general", g)
            + _get(params, "lav_carroceria_cada_10000", g) * _get(params, "precio_lavado_carroceria", g)
            + _get(params, "lav_motor_cada_10000", g) * _get(params, "precio_lavado_motor", g)
            + _get(params, "lav_chasis_cada_10000", g) * _get(params, "precio_lavado_chasis", g)
            + _get(params, "filtros_gasoil_cada_10000", g) * _get(params, "precio_filtro_gasoil", g)
            + _get(params, "filtros_aceite_cada_10000", g) * _get(params, "precio_filtro_aceite", g)
            + _get(params, "filtros_aire_cada_10000", g) * _get(params, "precio_filtro_aire", g),
            _get(params, "vida_util_service_km", g),
        )

        # 5. Reparación y mantenimiento material rodante
        rep_chasis = _safe_div(
            _get(params, "reparacion_chasis_pct", g)
            * (_get(params, "precio_chasis", g) - 6 * _get(params, "precio_cubierta", g))
            * vida_veh_anios,
            vida_veh_km,
        )
        rep_carroceria = _safe_div(
            _get(params, "reparacion_carroceria_pct", g) * _get(params, "precio_carroceria", g) * vida_veh_anios,
            vida_veh_km,
        )
        results["reparacion_mantenimiento"][g] = rep_chasis + rep_carroceria

        # 6. Depreciación del material rodante
        results["depreciacion_mr"][g] = _safe_div(
            _get(params, "valor_depreciable_chasis", g) * (1 + _pct(_get(params, "gastos_iniciales_material_rodante_pct", g)))
            + _get(params, "valor_depreciable_carroceria", g),
            vida_veh_km,
        )

        # 7. Seguro del vehículo
        results["seguro_vehiculo"][g] = _safe_div(
            _get(params, "premio_seguro_rc_anual", g)
            + _get(params, "costo_anual_franquicia", g)
            + _get(params, "costo_anual_seguro_chasis", g)
            + _get(params, "costo_anual_seguro_carroceria", g),
            km_prod,
        )

        # 8. Patentes y TNFT
        results["patentes_tnft"][g] = _safe_div(
            _get(params, "valor_patente_anual", g) + _get(params, "valor_tnft_anual", g),
            km_prod,
        )

        # 9. Salarios del personal
        staff_scenario = sum(_get(params, code, g, 0.0) for code in STAFF_CODES)
        results["salarios_personal"][g] = _safe_div(
            staff_scenario * base_salary_annual_per_staff[g],
            km_prod,
        )

        # 10. Seguros del personal
        results["seguros_personal"][g] = results["salarios_personal"][g] * seguros_personal_ratio[g]

        # 11. Máquinas, herramientas e inmuebles
        if km_empresa and km_empresa_base[g]:
            results["maq_herr_inmuebles"][g] = float(baseline_results["maq_herr_inmuebles"][g]) * (km_empresa_base[g] / km_empresa)

        # 12. Impuestos y tasas municipales
        if km_empresa and km_empresa_base[g]:
            results["impuestos_tasas_mun"][g] = float(baseline_results["impuestos_tasas_mun"][g]) * (km_empresa_base[g] / km_empresa)

        # 13. Costo del capital invertido
        parque_base = _get(base_params, "parque_movil", g, 0.0)
        if km_empresa and km_empresa_base[g]:
            parque_factor = _safe_div(parque, parque_base) if parque_base else 1.0
            results["capital_invertido"][g] = float(baseline_results["capital_invertido"][g]) * parque_factor * (km_empresa_base[g] / km_empresa)

        # 14. Licencia nacional habilitante
        conductores = _get(params, "conductores_x_veh", g, 0.0)
        results["lnh"][g] = _safe_div(conductores * base_lnh_annual_per_conductor[g], km_empresa)

        # 15. Control técnico
        results["control_tecnico"][g] = _safe_div(
            _get(params, "cantidad_controles_tecnicos_anual", g) * _get(params, "precio_control_tecnico", g),
            km_prod,
        )

        # 16. ACTRANS
        results["actrans"][g] = _safe_div(
            parque * _get(params, "aporte_actrans", g),
            _safe_div(km_empresa, 12.0),
        )

        # 18. Servicio de vigilancia
        if km_empresa and km_empresa_base[g]:
            results["vigilancia"][g] = float(baseline_results["vigilancia"][g]) * (km_empresa_base[g] / km_empresa)

        # 19. Cámaras de seguridad
        results["camaras_seguridad"][g] = _safe_div(
            _get(params, "costo_anual_camaras_seguridad", g),
            km_prod,
        )

        # 22. Ingresos Brutos - aproximación con recaudación media por km editable
        alicuota_iibb = _pct(_get(params, "alicuota_iibb_pct", g, 0.0))
        recaudacion_media_km = _get(params, "recaudacion_media_km", g, 0.0)
        if alicuota_iibb and recaudacion_media_km:
            results["iibb"][g] = recaudacion_media_km * alicuota_iibb

        # IPK / Tarifa
        results["ipk"][g] = _get(params, "ipk", g)

    subtotal_components = [
        "combustible",
        "lubricantes",
        "neumaticos",
        "engrase_lavado",
        "reparacion_mantenimiento",
        "depreciacion_mr",
        "seguro_vehiculo",
        "patentes_tnft",
        "salarios_personal",
        "seguros_personal",
        "maq_herr_inmuebles",
        "impuestos_tasas_mun",
        "capital_invertido",
        "lnh",
        "control_tecnico",
        "actrans",
        "peajes",
        "vigilancia",
        "camaras_seguridad",
    ]

    for g in GROUPS:
        subtotal = sum(float(results[c][g]) for c in subtotal_components)
        gg_pct = _pct(_get(params, "gasto_general_pct", g, 0.0))
        gastos_generales = _safe_div(gg_pct * subtotal, 1.0 - gg_pct) if gg_pct < 1 else 0.0
        total_sin_imp = subtotal + gastos_generales

        ger_pct = _pct(_get(params, "gerenciamiento_pct", g, 0.0))
        ger_per_pct = _pct(_get(params, "gerenciamiento_personal_pct", g, 0.0))
        ger_base = (
            results["combustible"][g]
            + results["lubricantes"][g]
            + results["neumaticos"][g]
            + results["engrase_lavado"][g]
            + float(results["reparacion_mantenimiento"][g])
            + float(results["seguro_vehiculo"][g])
            + float(results["patentes_tnft"][g])
            + float(results["capital_invertido"][g])
            + float(results["actrans"][g])
            + float(results["control_tecnico"][g])
            + float(results["impuestos_tasas_mun"][g])
            + float(results["lnh"][g])
            + float(results["peajes"][g])
            + float(results["vigilancia"][g])
            + float(results["camaras_seguridad"][g])
            + gastos_generales
        )
        ger_personal_base = results["salarios_personal"][g] + float(results["seguros_personal"][g])
        gerenciamiento = ger_base * ger_pct + ger_personal_base * ger_per_pct

        results["subtotal_sin_gg"][g] = subtotal
        results["gastos_generales"][g] = gastos_generales
        results["costo_total_sin_imp"][g] = total_sin_imp
        results["gerenciamiento"][g] = gerenciamiento

        costo_total = (
            total_sin_imp
            + float(results["imp_nac_comp"][g])
            + float(results["iibb"][g])
            + gerenciamiento
            + float(results["saldo_tecnico_iva"][g])
        )
        results["costo_total_km_sin_iva"][g] = costo_total
        results["tarifa_media"][g] = _safe_div(costo_total, results["ipk"][g])

    return results
