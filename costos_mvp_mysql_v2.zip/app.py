from collections import defaultdict
from flask import Flask, render_template, request, redirect, url_for, flash
from config import SECRET_KEY
from db import close_db, query_all, query_one, execute, executemany, commit, rollback
from services.calculator import calculate_results

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.teardown_appcontext(close_db)

def load_groups():
    return query_all("SELECT * FROM grupos_tarifarios ORDER BY orden")

def load_parameters_with_values(scenario_id=None):
    rows = query_all(
        """
        SELECT p.id AS parametro_id, p.codigo, p.modulo, p.descripcion, p.unidad,
               g.codigo AS grupo_codigo, g.nombre AS grupo_nombre,
               b.valor AS valor_base,
               v.valor AS valor_escenario
        FROM definiciones_parametros p
        CROSS JOIN grupos_tarifarios g
        LEFT JOIN valores_base b ON b.parametro_id = p.id AND b.grupo_id = g.id
        LEFT JOIN valores_escenario v ON v.parametro_id = p.id AND v.grupo_id = g.id AND v.escenario_id = %s
        ORDER BY p.modulo, p.id, g.orden
        """,
        (scenario_id if scenario_id else -1,)
    )
    grouped = defaultdict(lambda: defaultdict(dict))
    merged = defaultdict(dict)
    for r in rows:
        grouped[r["modulo"]][r["codigo"]]["label"] = r["descripcion"]
        grouped[r["modulo"]][r["codigo"]]["unit"] = r["unidad"]
        effective = r["valor_escenario"] if r["valor_escenario"] is not None else r["valor_base"]
        grouped[r["modulo"]][r["codigo"]].setdefault("values", {})
        grouped[r["modulo"]][r["codigo"]]["values"][r["grupo_codigo"]] = float(effective)
        merged[r["codigo"]][r["grupo_codigo"]] = float(effective)
    return grouped, merged

def load_base_params():
    rows = query_all(
        """
        SELECT p.codigo, g.codigo AS grupo_codigo, b.valor
        FROM valores_base b
        JOIN definiciones_parametros p ON p.id = b.parametro_id
        JOIN grupos_tarifarios g ON g.id = b.grupo_id
        """
    )
    out = defaultdict(dict)
    for r in rows:
        out[r["codigo"]][r["grupo_codigo"]] = float(r["valor"])
    return out

def load_baseline_results():
    rows = query_all(
        """
        SELECT d.codigo, g.codigo AS grupo_codigo, r.valor
        FROM resultados_base r
        JOIN definiciones_resultados d ON d.id = r.resultado_id
        JOIN grupos_tarifarios g ON g.id = r.grupo_id
        """
    )
    out = defaultdict(dict)
    for r in rows:
        out[r["codigo"]][r["grupo_codigo"]] = float(r["valor"])
    return out

def persist_results(scenario_id, results):
    defs = query_all("SELECT id, codigo FROM definiciones_resultados")
    result_id_map = {r["codigo"]: r["id"] for r in defs}
    groups = query_all("SELECT id, codigo FROM grupos_tarifarios")
    group_id_map = {g["codigo"]: g["id"] for g in groups}
    rows = []
    for code, per_group in results.items():
        for group_code, value in per_group.items():
            rows.append((scenario_id, result_id_map[code], group_id_map[group_code], float(value)))
    executemany(
        "INSERT INTO resultados_escenario (escenario_id, resultado_id, grupo_id, valor) VALUES (%s,%s,%s,%s) "
        "ON DUPLICATE KEY UPDATE valor=VALUES(valor), calculado_en=NOW()",
        rows
    )

@app.route("/")
def index():
    escenarios = query_all("SELECT * FROM escenarios WHERE activo=1 ORDER BY creado_en DESC")
    return render_template("index.html", escenarios=escenarios)

@app.route("/escenario/nuevo", methods=["POST"])
def nuevo_escenario():
    nombre = request.form.get("nombre", "").strip()
    descripcion = request.form.get("descripcion", "").strip() or None
    if not nombre:
        flash("Ingresá un nombre para el escenario.", "error")
        return redirect(url_for("index"))
    try:
        execute("INSERT INTO escenarios (nombre, descripcion) VALUES (%s,%s)", (nombre, descripcion))
        commit()
        flash("Escenario creado.", "ok")
    except Exception as exc:
        rollback()
        flash(f"No se pudo crear el escenario: {exc}", "error")
    return redirect(url_for("index"))

@app.route("/escenario/<int:scenario_id>", methods=["GET", "POST"])
def escenario(scenario_id):
    esc = query_one("SELECT * FROM escenarios WHERE id=%s", (scenario_id,))
    if not esc:
        flash("Escenario inexistente.", "error")
        return redirect(url_for("index"))
    if request.method == "POST":
        try:
            defs = query_all("SELECT id, codigo FROM definiciones_parametros")
            param_id_map = {r["codigo"]: r["id"] for r in defs}
            groups = query_all("SELECT id, codigo FROM grupos_tarifarios ORDER BY orden")
            group_id_map = {g["codigo"]: g["id"] for g in groups}
            payload = []
            for param_code in param_id_map:
                for g in group_id_map:
                    field = f"{param_code}__{g}"
                    raw = request.form.get(field)
                    if raw is None or raw == "":
                        continue
                    payload.append((scenario_id, param_id_map[param_code], group_id_map[g], float(raw.replace(",", "."))))
            if payload:
                executemany(
                    "INSERT INTO valores_escenario (escenario_id, parametro_id, grupo_id, valor) VALUES (%s,%s,%s,%s) "
                    "ON DUPLICATE KEY UPDATE valor=VALUES(valor)",
                    payload
                )
            base_params = load_base_params()
            _, merged_params = load_parameters_with_values(scenario_id)
            baseline_results = load_baseline_results()
            calc = calculate_results(base_params, merged_params, baseline_results)
            persist_results(scenario_id, calc)
            commit()
            flash("Escenario guardado y recalculado.", "ok")
        except Exception as exc:
            rollback()
            flash(f"Error al guardar/recalcular: {exc}", "error")
    modules, merged_params = load_parameters_with_values(scenario_id)
    groups = load_groups()
    result_rows = query_all(
        """
        SELECT d.orden, d.descripcion, d.codigo, g.codigo AS grupo_codigo,
               COALESCE(re.valor, rb.valor) AS valor,
               rb.valor AS base_valor
        FROM definiciones_resultados d
        CROSS JOIN grupos_tarifarios g
        LEFT JOIN resultados_base rb ON rb.resultado_id = d.id AND rb.grupo_id = g.id
        LEFT JOIN resultados_escenario re ON re.resultado_id = d.id AND re.grupo_id = g.id AND re.escenario_id = %s
        ORDER BY d.orden, g.orden
        """,
        (scenario_id,)
    )
    results = defaultdict(dict)
    for r in result_rows:
        results[r["codigo"]]["label"] = r["descripcion"]
        results[r["codigo"]]["order"] = r["orden"]
        results[r["codigo"]].setdefault("values", {})
        results[r["codigo"]].setdefault("base_values", {})
        results[r["codigo"]]["values"][r["grupo_codigo"]] = float(r["valor"])
        results[r["codigo"]]["base_values"][r["grupo_codigo"]] = float(r["base_valor"])
    ordered_results = sorted(results.items(), key=lambda x: x[1]["order"])
    return render_template("scenario.html", esc=esc, groups=groups, modules=modules, ordered_results=ordered_results)

if __name__ == "__main__":
    app.run(debug=True)
